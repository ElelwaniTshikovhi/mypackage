#  mypackage

This library was created as an example of hoe to publish your own python packages.

# How to install
...